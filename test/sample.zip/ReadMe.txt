Sample archive for ART.
